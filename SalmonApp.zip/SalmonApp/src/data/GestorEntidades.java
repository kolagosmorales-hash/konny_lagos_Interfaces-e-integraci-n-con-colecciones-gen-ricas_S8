package data;

import model.*;

import java.util.ArrayList;
import java.util.List;

public class GestorEntidades {

    private List<Registrable> entidades = new ArrayList<>();

    public void agregarEntidad(Registrable r) {
        entidades.add(r);
    }

    public List<Registrable> getEntidades() {
        return entidades;
    }

    public String generarResumen() {
        StringBuilder sb = new StringBuilder("=== ENTIDADES REGISTRADAS ===\n\n");

        for (Registrable r : entidades) {

            if (r instanceof Empleado) {
                sb.append("Tipo: Empleado\n");
            } else if (r instanceof Proveedor) {
                sb.append("Tipo: Proveedor\n");
            }

            sb.append(r.mostrarResumen()).append("\n\n");
        }

        return sb.toString();
    }
}
