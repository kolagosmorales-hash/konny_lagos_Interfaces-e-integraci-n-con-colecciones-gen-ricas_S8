package app;

import ui.MenuGUI;

public class Main {
    public static void main(String[] args) {
        MenuGUI gui = new MenuGUI();
        gui.iniciar();
    }
}