package ui;

import model.Empleado;
import model.Proveedor;
import model.Registrable;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class MenuGUI {

    private List<Registrable> registros = new ArrayList<>();

    public void iniciar() {
        int opcion;

        do {
            opcion = mostrarMenu();

            switch (opcion) {
                case 1 -> crearEmpleado();
                case 2 -> crearProveedor();
                case 3 -> mostrarResumenes();
                case 4 -> JOptionPane.showMessageDialog(null, "Saliendo del sistema...");
                default -> JOptionPane.showMessageDialog(null, "Opción inválida");
            }

        } while (opcion != 4);
    }

    private int mostrarMenu() {
        String menu = """
                --- Sistema Salmontt ---
                1. Registrar Empleado
                2. Registrar Proveedor
                3. Mostrar Resúmenes
                4. Salir

                Elija una opción:
                """;

        String opcion = JOptionPane.showInputDialog(menu);
        if (opcion == null) return 4;
        return Integer.parseInt(opcion);
    }

    private void crearEmpleado() {
        String nombre = JOptionPane.showInputDialog("Nombre del empleado:");
        String apellido = JOptionPane.showInputDialog("Apellido del empleado:");
        String cargo = JOptionPane.showInputDialog("Cargo del empleado:");

        Empleado emp = new Empleado(nombre, apellido, cargo);
        registros.add(emp);

        JOptionPane.showMessageDialog(null, "Empleado registrado correctamente.");
    }

    private void crearProveedor() {
        String nombre = JOptionPane.showInputDialog("Nombre del proveedor:");
        String rubro = JOptionPane.showInputDialog("Rubro:");

        Proveedor prov = new Proveedor(nombre, rubro); // SOLO DOS PARÁMETROS
        registros.add(prov);

        JOptionPane.showMessageDialog(null, "Proveedor registrado exitosamente.");
    }

    private void mostrarResumenes() {
        if (registros.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay registros aún.");
            return;
        }

        StringBuilder sb = new StringBuilder("=== RESÚMENES ===\n\n");

        for (Registrable r : registros) {
            sb.append(r.mostrarResumen()).append("\n\n");
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }
}