package model;

public interface Registrable {
    String mostrarResumen();
}