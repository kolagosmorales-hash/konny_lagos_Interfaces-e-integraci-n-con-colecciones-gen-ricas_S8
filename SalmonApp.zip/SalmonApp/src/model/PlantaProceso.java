package model;

public class PlantaProceso extends UnidadOperativa implements Registrable {

    private int id;
    private int capacidadProceso;
    private int toneladasProduccion;

    public PlantaProceso(int id, String nombre, String comuna, int capacidadProceso, int toneladasProduccion) {
        super(nombre, comuna);
        this.id = id;
        this.capacidadProceso = capacidadProceso;
        this.toneladasProduccion = toneladasProduccion;
    }

    public int getId() { return id; }
    public int getCapacidadProceso() { return capacidadProceso; }
    public int getToneladasProduccion() { return toneladasProduccion; }

    @Override
    public String mostrarResumen() {
        return "Planta de Proceso → ID: " + id +
                ", Nombre: " + getNombre() +
                ", Comuna: " + getComuna() +
                ", Capacidad Proceso: " + capacidadProceso +
                ", Producción: " + toneladasProduccion;
    }

    @Override
    public String toString() {
        return String.format(
                "PlantaProceso{id=%d, nombre='%s', comuna='%s', capacidadProceso=%d, toneladasProduccion=%d}",
                id, getNombre(), getComuna(), capacidadProceso, toneladasProduccion
        );
    }
}